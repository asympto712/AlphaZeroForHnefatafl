import taflNNet
import NeuralNet
from .azhnefatafl import self_play_function



