from ._azhnefatafl import *

__doc__ = _azhnefatafl.__doc__
if hasattr(_azhnefatafl, "__all__"):
    __all__ = _azhnefatafl.__all__